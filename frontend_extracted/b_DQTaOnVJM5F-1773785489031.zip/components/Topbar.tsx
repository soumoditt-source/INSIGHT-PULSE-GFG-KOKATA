'use client'

import React from 'react'
import { NeonBadge } from './NeonBadge'

export function Topbar() {
  const [time, setTime] = React.useState('')
  const [status, setStatus] = React.useState('ONLINE')

  React.useEffect(() => {
    const updateTime = () => {
      setTime(new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }))
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed top-0 left-64 right-0 h-16 glass border-b border-border/50 flex items-center justify-between px-8 z-20">
      <div className="flex items-center gap-4">
        <div className="text-sm font-mono text-muted-foreground">
          {time}
        </div>
        <NeonBadge variant="teal">NEURAL ENGINE ACTIVE</NeonBadge>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-xs text-muted-foreground">
          Status: <span className="text-emerald-400 font-semibold">{status}</span>
        </div>
        <div className="w-8 h-8 rounded-full bg-indigo-500/30 border border-indigo-500/50 flex items-center justify-center text-xs font-bold cursor-pointer hover:bg-indigo-500/40 transition-all">
          U
        </div>
      </div>
    </div>
  )
}
