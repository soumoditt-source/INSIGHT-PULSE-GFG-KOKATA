'use client'

import React, { useState, useRef, useEffect } from 'react'
import { GlassCard } from './GlassCard'
import { LoadingState } from './LoadingState'
import { NeonBadge } from './NeonBadge'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

interface ChatUIProps {
  onSendMessage?: (message: string) => Promise<void>
  isLoading?: boolean
}

export function ChatUI({ onSendMessage, isLoading = false }: ChatUIProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Welcome to InsightPulse AI. I am your neural data analyst. Ask me anything about your data - I can analyze, visualize, and provide predictive insights.',
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage = {
      id: Math.random().toString(),
      role: 'user' as const,
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput('')

    try {
      if (onSendMessage) {
        await onSendMessage(input)
      }

      const assistantMessage = {
        id: Math.random().toString(),
        role: 'assistant' as const,
        content: 'Analyzing your request... [Processing data analysis and generating insights]',
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      const errorMessage = {
        id: Math.random().toString(),
        role: 'assistant' as const,
        content: 'An error occurred while processing your request. Please try again.',
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    }
  }

  return (
    <div className="h-full flex flex-col">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-6 pr-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              'animate-slide-up',
              message.role === 'user' ? 'flex justify-end' : 'flex justify-start'
            )}
          >
            <div
              className={cn(
                'max-w-md px-4 py-3 rounded-lg glass-hover',
                message.role === 'user'
                  ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-100'
                  : 'bg-slate-700/20 border-slate-600/50 text-slate-100'
              )}
            >
              <p className="text-sm leading-relaxed">{message.content}</p>
              <span className="text-xs opacity-50 mt-1 block">
                {message.timestamp.toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <LoadingState message="Neural analysis in progress..." size="sm" />
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="space-y-3">
        <div className="flex flex-wrap gap-2 mb-3">
          {[
            'Analyze sales trends',
            'Show me growth metrics',
            'Compare regions',
          ].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setInput(suggestion)}
              className="text-xs px-3 py-1 rounded-full glass hover:glass-hover border border-border/50 transition-all duration-200"
            >
              {suggestion}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSendMessage()
              }
            }}
            placeholder="Ask me anything about your data..."
            className="flex-1 px-4 py-3 rounded-lg glass border border-border/50 focus:border-indigo-500/50 focus:outline-none focus:ring-1 focus:ring-indigo-500/30 transition-all duration-200 text-sm"
            disabled={isLoading}
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || !input.trim()}
            className={cn(
              'px-6 py-3 rounded-lg font-medium transition-all duration-200',
              isLoading || !input.trim()
                ? 'opacity-50 cursor-not-allowed glass'
                : 'glass-hover border-indigo-500/50 text-indigo-200 hover:shadow-glow'
            )}
          >
            {isLoading ? '...' : 'Send'}
          </button>
        </div>

        <NeonBadge variant="cyan" className="text-xs w-full text-center justify-center">
          💡 Tip: Upload your dataset or connect a data source to get started
        </NeonBadge>
      </div>
    </div>
  )
}
