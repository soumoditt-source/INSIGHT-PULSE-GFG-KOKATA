'use client'

import { Sidebar } from '@/components/Sidebar'
import { Topbar } from '@/components/Topbar'
import { StarField } from '@/components/StarField'
import { GlowingOrbs } from '@/components/GlowingOrbs'
import { BentoGrid, BentoGridItem } from '@/components/BentoGrid'
import { MetricCard } from '@/components/MetricCard'
import { NeonBadge } from '@/components/NeonBadge'
import { GlassCard } from '@/components/GlassCard'

export default function MLLabPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StarField />
      <GlowingOrbs />
      <Sidebar />
      <Topbar />

      <main className="ml-64 mt-16 p-8 relative z-2">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
              <NeonBadge variant="purple">MACHINE LEARNING</NeonBadge>
            </div>
            <h1 className="text-4xl font-bold font-outfit">ML Laboratory</h1>
            <p className="text-muted-foreground">Build, train, and deploy machine learning models</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <MetricCard label="Active Models" value="12" trend={{ value: 45, direction: 'up' }} icon="🤖" />
            <MetricCard label="Training Jobs" value="8" trend={{ value: 22, direction: 'up' }} icon="⚙️" />
            <MetricCard label="Model Accuracy" value="94.2" unit="%" trend={{ value: 8, direction: 'up' }} icon="🎯" />
            <MetricCard label="Inference Speed" value="124" unit="ms" trend={{ value: 12, direction: 'down' }} icon="⚡" />
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-bold font-outfit">Available Models</h2>
            <BentoGrid>
              <BentoGridItem index={0} title="Classification" description="Multi-class and binary classification tasks" icon="🔀" />
              <BentoGridItem index={1} title="Regression" description="Predict continuous numerical values" icon="📈" />
              <BentoGridItem index={2} title="Clustering" description="Group similar data points together" icon="🎯" />
              <BentoGridItem index={3} title="Anomaly Detection" description="Identify unusual patterns and outliers" icon="⚠️" />
              <BentoGridItem index={4} title="Time Series" description="Forecast temporal data patterns" icon="📊" span="double" />
            </BentoGrid>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <GlassCard glow={true}>
              <h3 className="text-lg font-bold font-outfit mb-4">Recent Training</h3>
              <div className="space-y-3">
                {[
                  { name: 'Sales Predictor', status: 'Complete', acc: '96.8%' },
                  { name: 'Customer Churn', status: 'Running', acc: '92.1%' },
                  { name: 'Demand Forecast', status: 'Complete', acc: '94.5%' },
                ].map((model, i) => (
                  <div key={i} className="flex items-center justify-between pb-3 border-b border-border/30">
                    <div>
                      <p className="font-medium">{model.name}</p>
                      <p className="text-xs text-muted-foreground">{model.status}</p>
                    </div>
                    <span className="text-sm font-semibold text-emerald-400">{model.acc}</span>
                  </div>
                ))}
              </div>
            </GlassCard>

            <GlassCard glow={true}>
              <h3 className="text-lg font-bold font-outfit mb-4">Model Comparison</h3>
              <div className="space-y-3">
                {[
                  { name: 'Random Forest', score: '94.2%' },
                  { name: 'XGBoost', score: '95.8%' },
                  { name: 'Neural Network', score: '93.5%' },
                ].map((model, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{model.name}</span>
                      <span className="text-indigo-400">{model.score}</span>
                    </div>
                    <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
                        style={{ width: model.score }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  )
}
