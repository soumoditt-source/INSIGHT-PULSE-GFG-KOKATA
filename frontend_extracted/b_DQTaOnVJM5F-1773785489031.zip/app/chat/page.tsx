'use client'

import React, { useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { Topbar } from '@/components/Topbar'
import { StarField } from '@/components/StarField'
import { GlowingOrbs } from '@/components/GlowingOrbs'
import { ChatUI } from '@/components/ChatUI'
import { ChartPlaceholder } from '@/components/ChartPlaceholder'
import { GlassCard } from '@/components/GlassCard'
import { NeonBadge } from '@/components/NeonBadge'

export default function ChatPage() {
  const [isLoading, setIsLoading] = useState(false)

  const handleSendMessage = async (message: string) => {
    setIsLoading(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <StarField />
      <GlowingOrbs />

      <Sidebar />
      <Topbar />

      <main className="ml-64 mt-16 p-8 relative z-2">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-180px)]">
            {/* Chat Column */}
            <div className="lg:col-span-1 flex flex-col">
              <div className="mb-4 space-y-2">
                <h1 className="text-2xl font-bold font-outfit">Data Chat</h1>
                <p className="text-sm text-muted-foreground">
                  Ask questions about your data
                </p>
              </div>

              <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden" glow={true}>
                <div className="p-6 flex-1 flex flex-col overflow-hidden">
                  <ChatUI
                    onSendMessage={handleSendMessage}
                    isLoading={isLoading}
                  />
                </div>
              </GlassCard>
            </div>

            {/* Analytics Column */}
            <div className="lg:col-span-2 flex flex-col gap-6 overflow-y-auto pr-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold font-outfit">Live Analytics</h2>
                  <NeonBadge variant="teal">REAL-TIME</NeonBadge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Dynamic visualizations of your data
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 auto-rows-[300px]">
                <div className="animate-slide-up">
                  <ChartPlaceholder title="Sales Over Time" type="line" />
                </div>
                <div className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
                  <ChartPlaceholder title="Regional Distribution" type="bar" />
                </div>
                <div className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
                  <ChartPlaceholder title="Performance Metrics" type="scatter" />
                </div>
                <div className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
                  <ChartPlaceholder title="Trend Analysis" type="line" />
                </div>
              </div>

              {/* Data Summary */}
              <div className="space-y-3 mt-6">
                <h3 className="text-lg font-bold font-outfit">Data Summary</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Total Records', value: '1.2M', trend: '+15%' },
                    { label: 'Avg Latency', value: '245ms', trend: '-8%' },
                    { label: 'Success Rate', value: '99.8%', trend: '+0.2%' },
                  ].map((item, i) => (
                    <GlassCard key={i} glow={false} hover={true}>
                      <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
                      <div className="flex items-end gap-2">
                        <span className="text-2xl font-bold text-foreground font-outfit">
                          {item.value}
                        </span>
                        <span className="text-xs text-emerald-400">{item.trend}</span>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
