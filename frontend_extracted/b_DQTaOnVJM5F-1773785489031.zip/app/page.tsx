'use client'

import { Sidebar } from '@/components/Sidebar'
import { Topbar } from '@/components/Topbar'
import { StarField } from '@/components/StarField'
import { GlowingOrbs } from '@/components/GlowingOrbs'
import { BentoGrid, BentoGridItem } from '@/components/BentoGrid'
import { NeonBadge } from '@/components/NeonBadge'
import { MetricCard } from '@/components/MetricCard'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StarField />
      <GlowingOrbs />
      
      <Sidebar />
      <Topbar />

      <main className="ml-64 mt-16 p-8 relative z-2">
        <div className="max-w-7xl mx-auto space-y-12">
          {/* Hero Section */}
          <div className="space-y-6 pt-8 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <NeonBadge variant="indigo">NEURAL INTELLIGENCE PLATFORM</NeonBadge>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold font-outfit text-balance">
              <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-magenta-400 bg-clip-text text-transparent">
                The Future of Data Intelligence
              </span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
              Experience the world's most advanced AI-powered intelligence bureau. Real-time data visualization, predictive analytics, and machine learning insights at your fingertips.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <Link
                href="/chat"
                className="px-6 py-3 rounded-lg glass-hover border border-indigo-500/50 text-indigo-200 font-medium hover:shadow-glow transition-all duration-300"
              >
                Start Analyzing
              </Link>
              <button className="px-6 py-3 rounded-lg glass border border-border/50 text-foreground font-medium hover:glass-hover transition-all duration-300">
                Explore Features
              </button>
            </div>
          </div>

          {/* Live Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <MetricCard
              label="Data Points Processed"
              value="2.4B"
              unit="monthly"
              trend={{ value: 28, direction: 'up' }}
              icon="📊"
            />
            <MetricCard
              label="Prediction Accuracy"
              value="98.7"
              unit="%"
              trend={{ value: 12, direction: 'up' }}
              icon="🎯"
            />
            <MetricCard
              label="Active Queries"
              value="1,247"
              unit="live"
              trend={{ value: 45, direction: 'up' }}
              icon="⚡"
            />
            <MetricCard
              label="System Uptime"
              value="99.99"
              unit="%"
              trend={{ value: 0, direction: 'up' }}
              icon="✨"
            />
          </div>

          {/* Main Bento Grid */}
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold font-outfit mb-2">Powerful Features</h2>
              <p className="text-muted-foreground">Unlock advanced data analysis with cutting-edge AI capabilities</p>
            </div>

            <BentoGrid>
              <BentoGridItem
                index={0}
                title="Data Chat"
                description="Conversational AI for data exploration and insights"
                icon="💬"
                span="double"
              >
                <div className="text-xs text-muted-foreground mt-4">
                  Natural language queries • Real-time analysis • Smart suggestions
                </div>
              </BentoGridItem>

              <BentoGridItem
                index={1}
                title="ML Laboratory"
                description="Build and train models"
                icon="⚗️"
              >
                <div className="text-xs text-muted-foreground">
                  Classification • Regression • Clustering
                </div>
              </BentoGridItem>

              <BentoGridItem
                index={2}
                title="Data Profiling"
                description="Comprehensive data analysis"
                icon="📈"
                span="tall"
              >
                <div className="flex flex-col gap-2 mt-4">
                  <div className="flex items-center justify-between text-xs">
                    <span>Data Quality</span>
                    <span className="text-emerald-400 font-semibold">95%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div className="h-full w-[95%] bg-gradient-to-r from-emerald-500 to-teal-500" />
                  </div>
                </div>
              </BentoGridItem>

              <BentoGridItem
                index={3}
                title="Geographic View"
                description="Map-based insights"
                icon="🗺️"
              >
                <div className="text-xs text-muted-foreground">
                  Global data distribution • Regional analytics
                </div>
              </BentoGridItem>

              <BentoGridItem
                index={4}
                title="Query History"
                description="Track and manage queries"
                icon="⏱️"
              >
                <div className="text-xs text-muted-foreground">
                  Audit trail • Performance metrics
                </div>
              </BentoGridItem>

              <BentoGridItem
                index={5}
                title="Smart Dashboards"
                description="Customizable intelligence boards"
                icon="📊"
              >
                <div className="text-xs text-muted-foreground">
                  Real-time updates • Saved views
                </div>
              </BentoGridItem>
            </BentoGrid>
          </div>

          {/* CTA Section */}
          <div className="glass rounded-lg p-12 border border-indigo-500/30 text-center space-y-6 mt-16 animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <h2 className="text-3xl font-bold font-outfit">Ready to Transform Your Data?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Join thousands of organizations using InsightPulse AI to unlock actionable insights from their data.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link
                href="/chat"
                className="px-8 py-3 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white font-medium transition-all duration-300 shadow-glow hover:shadow-glow-lg"
              >
                Start Free Trial
              </Link>
              <button className="px-8 py-3 rounded-lg glass border border-border/50 font-medium hover:glass-hover transition-all duration-300">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
