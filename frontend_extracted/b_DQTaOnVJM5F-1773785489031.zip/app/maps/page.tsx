'use client'

import { Sidebar } from '@/components/Sidebar'
import { Topbar } from '@/components/Topbar'
import { StarField } from '@/components/StarField'
import { GlowingOrbs } from '@/components/GlowingOrbs'
import { GlassCard } from '@/components/GlassCard'
import { NeonBadge } from '@/components/NeonBadge'
import { MetricCard } from '@/components/MetricCard'

export default function MapsPage() {
  const regions = [
    { name: 'North America', value: '2.4M', trend: 'up' },
    { name: 'Europe', value: '1.8M', trend: 'up' },
    { name: 'Asia Pacific', value: '3.2M', trend: 'up' },
    { name: 'Latin America', value: '620K', trend: 'down' },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      <StarField />
      <GlowingOrbs />
      <Sidebar />
      <Topbar />

      <main className="ml-64 mt-16 p-8 relative z-2">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse" />
              <NeonBadge variant="teal">GEOGRAPHIC ANALYTICS</NeonBadge>
            </div>
            <h1 className="text-4xl font-bold font-outfit">Map View</h1>
            <p className="text-muted-foreground">Global data distribution and regional insights</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <MetricCard label="Total Locations" value="145" trend={{ value: 8, direction: 'up' }} icon="🗺️" />
            <MetricCard label="Active Regions" value="6" trend={{ value: 0, direction: 'up' }} icon="🌍" />
            <MetricCard label="Avg Latency" value="124" unit="ms" trend={{ value: 12, direction: 'down' }} icon="⚡" />
            <MetricCard label="Data Centers" value="23" trend={{ value: 2, direction: 'up' }} icon="🏢" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Map Placeholder */}
            <GlassCard glow={true} className="lg:col-span-2" hover={false}>
              <h3 className="text-lg font-bold font-outfit mb-4">Global Distribution</h3>
              <div className="w-full h-96 bg-slate-900/50 rounded-lg border border-border/20 flex items-center justify-center relative overflow-hidden">
                {/* Simulated map with animated nodes */}
                <svg className="w-full h-full" viewBox="0 0 1000 600">
                  {/* World map background */}
                  <defs>
                    <linearGradient id="mapGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" style={{ stopColor: '#1a1a2e', stopOpacity: 1 }} />
                      <stop offset="100%" style={{ stopColor: '#0f0f1e', stopOpacity: 1 }} />
                    </linearGradient>
                  </defs>
                  <rect width="1000" height="600" fill="url(#mapGrad)" />

                  {/* Animated data points */}
                  {[
                    { x: 200, y: 150, label: 'North America' },
                    { x: 450, y: 120, label: 'Europe' },
                    { x: 700, y: 200, label: 'Asia' },
                    { x: 300, y: 400, label: 'South America' },
                    { x: 600, y: 420, label: 'Africa' },
                  ].map((point, i) => (
                    <g key={i}>
                      <circle
                        cx={point.x}
                        cy={point.y}
                        r="15"
                        fill="#6366f1"
                        opacity="0.8"
                        style={{
                          animation: `pulse-glow 2s ease-in-out infinite`,
                          animationDelay: `${i * 0.2}s`,
                        }}
                      />
                      <circle
                        cx={point.x}
                        cy={point.y}
                        r="8"
                        fill="#06b6d4"
                        opacity="0.6"
                      />
                    </g>
                  ))}
                </svg>

                <div className="absolute bottom-4 left-4 text-xs text-muted-foreground bg-black/40 px-3 py-2 rounded">
                  Click regions for detailed analytics
                </div>
              </div>
            </GlassCard>

            {/* Regional Breakdown */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold font-outfit">Regional Breakdown</h3>
              <div className="space-y-3">
                {regions.map((region, i) => (
                  <GlassCard key={i} hover={true}>
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium text-sm">{region.name}</p>
                      <span className={`text-xs font-semibold ${region.trend === 'up' ? 'text-emerald-400' : 'text-red-400'}`}>
                        {region.trend === 'up' ? '↑' : '↓'}
                      </span>
                    </div>
                    <p className="text-lg font-bold text-indigo-400">{region.value}</p>
                    <div className="mt-2 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
                        style={{
                          width: `${Math.random() * 40 + 60}%`,
                        }}
                      />
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          </div>

          {/* Regional Stats */}
          <GlassCard glow={true}>
            <h3 className="text-lg font-bold font-outfit mb-4">Performance by Region</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/30">
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Region</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Requests</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Avg Response</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Success Rate</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {regions.map((region, i) => (
                    <tr key={i} className="border-b border-border/20 hover:bg-slate-800/20 transition-colors">
                      <td className="py-3 px-4">{region.name}</td>
                      <td className="py-3 px-4 text-indigo-400">{Math.floor(Math.random() * 1000) + 500}K</td>
                      <td className="py-3 px-4 text-purple-400">{Math.floor(Math.random() * 200) + 50}ms</td>
                      <td className="py-3 px-4 text-emerald-400">{(Math.random() * 4 + 96).toFixed(1)}%</td>
                      <td className="py-3 px-4">
                        <span className="text-xs px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-200">Healthy</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </div>
      </main>
    </div>
  )
}
