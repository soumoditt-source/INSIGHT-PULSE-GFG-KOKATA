'use client'

import { Sidebar } from '@/components/Sidebar'
import { Topbar } from '@/components/Topbar'
import { StarField } from '@/components/StarField'
import { GlowingOrbs } from '@/components/GlowingOrbs'
import { GlassCard } from '@/components/GlassCard'
import { NeonBadge } from '@/components/NeonBadge'
import { MetricCard } from '@/components/MetricCard'

export default function ProfilerPage() {
  const columns = [
    { name: 'customer_id', type: 'Integer', null: '0%', distinct: '10,247' },
    { name: 'purchase_amount', type: 'Float', null: '1.2%', distinct: '8,942' },
    { name: 'transaction_date', type: 'Date', null: '0%', distinct: '1,240' },
    { name: 'category', type: 'String', null: '3.5%', distinct: '28' },
    { name: 'region', type: 'String', null: '0%', distinct: '5' },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      <StarField />
      <GlowingOrbs />
      <Sidebar />
      <Topbar />

      <main className="ml-64 mt-16 p-8 relative z-2">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
              <NeonBadge variant="cyan">DATA PROFILING</NeonBadge>
            </div>
            <h1 className="text-4xl font-bold font-outfit">Data Profiler</h1>
            <p className="text-muted-foreground">Comprehensive analysis of your dataset characteristics</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <MetricCard label="Total Records" value="2.4M" trend={{ value: 12, direction: 'up' }} icon="📊" />
            <MetricCard label="Data Quality" value="98.5" unit="%" trend={{ value: 5, direction: 'up' }} icon="✓" />
            <MetricCard label="Missing Values" value="1.2" unit="%" trend={{ value: 3, direction: 'down' }} icon="⚠️" />
            <MetricCard label="Columns" value="47" trend={{ value: 0, direction: 'up' }} icon="📋" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quality Score */}
            <GlassCard glow={true} className="lg:col-span-1">
              <h3 className="text-lg font-bold font-outfit mb-6">Quality Score</h3>
              <div className="text-center">
                <div className="relative w-32 h-32 mx-auto mb-6">
                  <div className="absolute inset-0 rounded-full border-8 border-indigo-500/20" />
                  <div
                    className="absolute inset-0 rounded-full border-8 border-transparent border-t-indigo-500 border-r-purple-500"
                    style={{
                      transform: 'rotate(var(--rotation, 235deg))',
                    }}
                  />
                  <div className="absolute inset-2 rounded-full bg-background flex items-center justify-center">
                    <span className="text-3xl font-bold font-outfit text-indigo-400">98</span>
                  </div>
                </div>
                <p className="text-muted-foreground text-sm">Excellent data quality</p>
              </div>
            </GlassCard>

            {/* Column Details */}
            <div className="lg:col-span-2">
              <h3 className="text-lg font-bold font-outfit mb-4">Column Profile</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {columns.map((col, i) => (
                  <GlassCard key={i} hover={true} className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">{col.name}</p>
                        <p className="text-xs text-muted-foreground">{col.type}</p>
                      </div>
                      <div className="flex gap-4 text-xs">
                        <div>
                          <p className="text-muted-foreground">Null</p>
                          <p className="font-semibold text-cyan-400">{col.null}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Distinct</p>
                          <p className="font-semibold text-indigo-400">{col.distinct}</p>
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          </div>

          {/* Distribution Analysis */}
          <GlassCard glow={true}>
            <h3 className="text-lg font-bold font-outfit mb-6">Distribution Analysis</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { name: 'purchase_amount', skew: 'Normal', kurt: 'Mesokurtic' },
                { name: 'customer_age', skew: 'Slight Right', kurt: 'Platykurtic' },
                { name: 'transaction_count', skew: 'Right Skewed', kurt: 'Leptokurtic' },
              ].map((dist, i) => (
                <div key={i} className="p-4 bg-slate-800/30 rounded-lg border border-border/20">
                  <p className="font-medium mb-3">{dist.name}</p>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Skewness</span>
                      <span className="text-indigo-400">{dist.skew}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Kurtosis</span>
                      <span className="text-purple-400">{dist.kurt}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </main>
    </div>
  )
}
