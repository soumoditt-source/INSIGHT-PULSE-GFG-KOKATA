// API Service Layer for InsightPulse AI
// This service handles all backend communication

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export class APIClient {
  private baseURL: string

  constructor(baseURL = API_BASE) {
    this.baseURL = baseURL
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseURL}${endpoint}`
    
    try {
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      })

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`)
      }

      return response.json()
    } catch (error) {
      console.error('API Request Error:', error)
      throw error
    }
  }

  // Data Management
  async uploadDataset(file: File): Promise<{ datasetId: string }> {
    const formData = new FormData()
    formData.append('file', file)

    const response = await fetch(`${this.baseURL}/api/upload`, {
      method: 'POST',
      body: formData,
    })

    return response.json()
  }

  async getDatasetInfo(datasetId: string) {
    return this.request(`/api/datasets/${datasetId}`)
  }

  // Chat/Query
  async generateQuery(message: string, datasetId?: string) {
    return this.request('/api/generate', {
      method: 'POST',
      body: JSON.stringify({ message, datasetId }),
    })
  }

  // ML Analysis
  async analyzeWithML(datasetId: string, modelType: string) {
    return this.request('/api/analyze', {
      method: 'POST',
      body: JSON.stringify({ datasetId, modelType }),
    })
  }

  // Data Profiling
  async profileDataset(datasetId: string) {
    return this.request(`/api/profile/${datasetId}`)
  }

  // Visualization
  async getVisualization(queryId: string) {
    return this.request(`/api/visualizations/${queryId}`)
  }

  // Status
  async getSystemStatus() {
    return this.request('/api/status')
  }
}

// Singleton instance
export const apiClient = new APIClient()
